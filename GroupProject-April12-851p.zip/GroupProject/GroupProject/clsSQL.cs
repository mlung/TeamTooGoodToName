﻿using System;
using System.Windows.Forms;
using System.Configuration; //Config file
using System.Data.OleDb; //Database connectivity
using System.Collections;

public static class clsSQL //Static: Only one instance of this across the entire application!
{
    public static OleDbConnection mdb = new OleDbConnection();
    private static string dbFilename = "";

    public static ArrayList queryVendor (string sql)
    {
        ArrayList vendors = new ArrayList();
        return vendors;
    }

    public static ArrayList queryPurchase(string sql)
    {
        ArrayList purchases = new ArrayList();
        return purchases;
    }

    public static ArrayList queryMedia(string sql)
    {
        ArrayList media = new ArrayList();
        try
        {
            openDatabaseConnection();
            mdb.Open();
            OleDbCommand cmd;
            cmd = new OleDbCommand(sql, mdb);
            OleDbDataReader rdr;
            rdr = cmd.ExecuteReader();
            while (rdr.Read() == true)
            {
                clsMedia newMedia = new clsMedia((int)rdr["MediaID"], (string)rdr["Title"], (string)rdr["Type"]);
                media.Add(newMedia);
            }
            rdr.Close();
        }
        catch (Exception ex)
        {
            MessageBox.Show("There was an unexpected problem reading from the DB: " +
                 ex.Message);
        }
        finally
        {
            closeDatabaseConnection();
        }
        return media;
    }

    private static void openDatabaseConnection()
    {
        string connectionString = ConfigurationManager.AppSettings["DBConnectionString"] + dbFilename;
        mdb = new OleDbConnection(connectionString);
    }

    private static void closeDatabaseConnection()
    {
        if (mdb != null)
        {
            mdb.Close();
        }
    }

    public static string DBFileName
    {
        set { dbFilename = value; }
        get { return dbFilename; }
    }
}