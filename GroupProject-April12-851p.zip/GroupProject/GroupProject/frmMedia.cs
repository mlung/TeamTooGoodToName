﻿//MEDIA MANAGEMENT
//Miranda Lung

using System;
using System.Windows.Forms;
using System.IO; //File prompts
using System.Collections;

public partial class frmMedia : Form
{
    
    public frmMedia()
    {
        InitializeComponent();//Initialize - see frmMain.Designer.cs
    }

    private void btnExit_Click(object sender, EventArgs e)
    {
        Close();
    }



    private void openToolStripMenuItem_Click(object sender, EventArgs e)
    {
        OpenFileDialog ofd;
        try
        {
            ofd = new OpenFileDialog();
            ofd.Filter = "Client DB files (*.accdb)|*.accdb|All files (*.*)|*.*";
            ofd.InitialDirectory = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Database");
            ofd.InitialDirectory = AppDomain.CurrentDomain.BaseDirectory;
            if (ofd.ShowDialog() == DialogResult.OK)
            {
                clsSQL.DBFileName = ofd.FileName;
            }
        }

        catch (Exception ex)
        {
            MessageBox.Show("An unexpected error has occurred while attempting to open this file." + Environment.NewLine + Environment.NewLine
            + "Error Message:" + Environment.NewLine
            + ex.Message);
        }


    }

    private void btnReadDB_Click(object sender, EventArgs e)
    {
        ArrayList media;
        media = clsSQL.queryMedia("SELECT * FROM MEDIA");
        lstMedia.Items.Clear();
        foreach (clsMedia m in media)
        {
            lstMedia.Items.Add(m.ID + "   " + m.Title + "   " + m.Type);
        }
    }
}