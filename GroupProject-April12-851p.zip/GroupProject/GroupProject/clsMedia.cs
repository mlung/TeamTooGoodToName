﻿//Miranda Lung, CNIT 255 Group Project
//Last edited 4/12/2015

public class clsMedia
    //Class for media objects: DVDs, books, movies, etc.
{
    private int myID;
    private string myTitle;
    private string myType;

    public clsMedia()
    {
        myID = -1;
        myTitle = "";
        myType = "";
    }

    public clsMedia(int id, string title, string type)
    {
        myID = id;
        myTitle = title;
        myType = type;
    }

    public int ID
    {
        get { return myID; }
        set { myID = value; }
    }

    public string Title
    {
        get { return myTitle; }
        set { myTitle = value; }
    }

    public string Type
    {
        get { return myType; }
        set { myType = value; }
    }
}