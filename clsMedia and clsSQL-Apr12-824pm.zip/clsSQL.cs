﻿using System;
using System.Windows.Forms;
using System.Configuration; //Config file
using System.Data.OleDb; //Database connectivity
using System.Collections;

public class clsSQL
{
    public static ArrayList queryVendor (string sql)
    {
        ArrayList vendors = new ArrayList();
        return vendors;
    }

    public static ArrayList queryPurchase(string sql)
    {
        ArrayList purchases = new ArrayList();
        return purchases;
    }

    public static ArrayList queryMedia(OleDbConnection db, string sql)
    {
        ArrayList media = new ArrayList();
        try
        {
            //openDatabaseConnection(db);
            db.Open();
            OleDbCommand cmd;
            cmd = new OleDbCommand(sql, db);
            OleDbDataReader rdr;
            rdr = cmd.ExecuteReader();
            while (rdr.Read() == true)
            {
                clsMedia newMedia = new clsMedia((int)rdr["MediaID"], (string)rdr["Title"], (string)rdr["Type"]);
                media.Add(newMedia);
            }
            rdr.Close();
        }
        catch (Exception ex)
        {
            MessageBox.Show("There was an unexpected problem reading from the DB: " +
                 ex.Message);
        }
        finally
        {
            //closeDatabaseConnection(db);
        }
        return media;
    }

    private void openDatabaseConnection(OleDbConnection db)
    {
        //string connectionString = ConfigurationManager.AppSettings["DBConnectionString"] + gFilename;
        //db = new OleDbConnection(connectionString);
    }

    private void closeDatabaseConnection(OleDbConnection db)
    {
        if (db != null)
        {
            db.Close();
        }
    }
}